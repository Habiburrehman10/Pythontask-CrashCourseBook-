class Battery():
    def __init__(self,size,cell,amp):
        self.amp=amp
        self.size=size
        self.cell=cell

    def describe(self):
        print(f'this is {self.amp} amp battery and size is {self.size}')
