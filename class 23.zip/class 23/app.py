
from Electriccar import ElectricCar
from car import *
from Battery import *

ec1=ElectricCar('tesla','hero',19)
ec1.battery.describe()
ec1.get_descriptive_name()
