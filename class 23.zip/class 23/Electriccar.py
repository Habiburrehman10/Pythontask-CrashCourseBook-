from car import *
from Battery import *
class ElectricCar(Car):
    def __init__(self, make, model, year):
 
        super().__init__(make, model, year)
        #super()takes you to the parent class initializer
        self.battery = Battery("Exide",27,200)
        
        
   
